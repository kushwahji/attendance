package com.santosh.models;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by ext-santoshk on 20-11-2019.
 */
@Entity
@Table(name = "otptransaction")
@Data
@Getter
@Setter
public class MgmtOtpTranaction {
  @Id
  @GeneratedValue
  @Column(name = "id")
  private Integer id;

  @Column(name = "username")
  private String userName;

  @Column(name = "otpvalue")
  private String otpValue;

  @Column(name = "otpcreationtime")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS", timezone = "IST")
  private Date otpCreationTime;

  @Column(name = "otpexpirytime")
  private Date otpExpiryTime;

  @Column(name = "otpverificationfailcount")
  private int otpVerificationFailCount;

  @Column(name = "status")
  private int status;

  @Column(name = "mobileno")
  private String mobileNo;

  public MgmtOtpTranaction() {

  }
}
