package com.santosh.repository;

import com.santosh.models.ERole;
import com.santosh.models.Role;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import com.santosh.models.ERole;
import com.santosh.models.Role;


@Repository
public interface RoleRepository extends PagingAndSortingRepository<Role, Integer> {
Role findByName(ERole name);
}
