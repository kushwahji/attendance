package com.santosh.payload.request;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by ext-santoshk on 06-03-2020.
 */
@Getter
@Setter
public class WorkLogRequest {
  private Long id;
  private String username;
  private String dateStarted;
  private String project;
  private String dateEnded;
  private String jiraTask;
  private String jiraTicketNo;
  private String timeSpend;
  private String workDescription;
  private String month;
  private String download;
}
