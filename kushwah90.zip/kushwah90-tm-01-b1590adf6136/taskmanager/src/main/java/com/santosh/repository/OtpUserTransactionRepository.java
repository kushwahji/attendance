
package com.santosh.repository;

import com.santosh.models.MgmtOtpTranaction;
import org.springframework.data.repository.CrudRepository;
import com.santosh.models.MgmtOtpTranaction;

/**
 * Created by ext-santoshk on 19-11-2019.
 */
public interface OtpUserTransactionRepository extends CrudRepository<MgmtOtpTranaction, Integer> {
  /**
   *
   * @param userName
   * @return
   */
  MgmtOtpTranaction findOtpUserByUserName(String userName);
}
