package com.santosh.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

/**
 * Created by ext-santoshk on 16-03-2020.
 */
@Getter
@Setter
@Entity
@Table(	name = "worklog")
public class WorkLog {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  private String username;
  private String dateStarted;
  private String project;
  private String jiraTask;
  private String jiraTicketNo;
  private String timeSpend;
  private String workDescription;
  private String month;
}
