package com.santosh.payload.request;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by ext-santoshk on 20-02-2020.
 */
@Getter
@Setter
public class TaskRequest {
  private int id;
  private String username;
  private String days;
  private String logInDate;
  private String logOutDate;
  private String logInTime;
  private String logOutTime;
  private String lessHrs;
  private String extraHrs;
  private String spendHrs;
  private String projectName;
  private String remarks;
  private String module;
  private String month;
  private int year;


}
