package com.santosh.payload.response;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by ext-santoshk on 04-05-2020.
 */
@Getter
@Setter
public class BillingEntity {
  private int Sr_NO;
  private String Project_Name;
  private String Resource_Name;
  private String Date;
  private String Start_Time;
  private String End_Time;
  private String JIRA_No;
}
