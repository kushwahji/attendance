package com.santosh.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Created by ext-santoshk on 20-11-2019.
 */
@Getter
@Setter
public class MgmtOtpStatus {
  @JsonProperty("userName")
  private String userName = "";

  @JsonProperty("otp")
  private String otp = "";

  @JsonProperty("resendOTP")
  private int resendOTP = 0;

  @JsonProperty("mobileNumber")
  private String mobileNumber = "";

  @JsonProperty("emailAddress")
  private String emailAddress = "";

  @JsonProperty("internalResponseCode")
  private String internalResponseCode = "";

  @JsonProperty("failedVerificationCounter")
  private String failedVerificationCounter = "";
}
