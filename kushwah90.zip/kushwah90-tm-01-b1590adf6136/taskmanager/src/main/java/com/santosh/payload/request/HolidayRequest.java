package com.santosh.payload.request;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by ext-santoshk on 06-03-2020.
 */
@Getter
@Setter
public class HolidayRequest {
  private String month;
  private int year;
}
