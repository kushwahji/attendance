package com.santosh.payload.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PasswordRequest {

  private String username;
  private String email;
  private String password;
  private String otp;
}
