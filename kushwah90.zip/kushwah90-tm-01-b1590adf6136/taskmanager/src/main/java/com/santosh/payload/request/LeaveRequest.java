package com.santosh.payload.request;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by ext-santoshk on 20-02-2020.
 */
@Getter
@Setter
public class LeaveRequest {
  private String username;
  private String from;
  private String manager;
  private String managerEmail;
  private String cc;
  private String subject;
  private String body;


}
