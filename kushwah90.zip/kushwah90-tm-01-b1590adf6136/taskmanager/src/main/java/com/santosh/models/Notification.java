package com.santosh.models;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by ext-santoshk on 16-03-2020.
 */
@Getter
@Setter
public class Notification {
  private String birthday;
  private String holiday;
  private int notifyCount;
}
