package com.santosh.repository;

import com.santosh.models.HolidayEntity;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import com.santosh.models.HolidayEntity;

import java.util.List;


@Repository
public interface HolidaysRepository extends PagingAndSortingRepository<HolidayEntity, Integer> {
  List<HolidayEntity> findByYear(int year);

}
