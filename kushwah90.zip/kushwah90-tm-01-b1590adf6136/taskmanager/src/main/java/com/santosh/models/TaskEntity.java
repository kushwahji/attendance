package com.santosh.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

/**
 * Created by ext-santoshk on 20-02-2020.
 */
@Getter
@Setter
@Entity
@Table(name = "task")
public class TaskEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id;
  private String username;
  private String days;
  private String logInDate;
  private String logOutDate;
  private String logInTime;
  private String logOutTime;
  private String spendHrs;
  private String lessHrs;
  private String extraHrs;
  private String projectName;
  private String remarks;
  private String module;
  private String month;
  private int year;
}
