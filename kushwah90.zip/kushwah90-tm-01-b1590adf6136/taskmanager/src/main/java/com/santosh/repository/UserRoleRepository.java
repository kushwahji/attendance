package com.santosh.repository;


import com.santosh.models.User;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import com.santosh.models.User;

/**
 * Created by ext-parshotam on 15-11-2017.
 */
@Repository
public interface UserRoleRepository extends PagingAndSortingRepository<User, Integer> {
    //public User getByRoleName(String roleid);
}
