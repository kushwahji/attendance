export const environment = {
  TASK_API: 'http://192.168.26.141:4200/api/test/',
  AUTH_API: 'http://192.168.26.141:4200/api/auth/',
  
  //TASK_API: 'http://localhost:8080/api/test/',
  //AUTH_API: 'http://localhost:8080/api/auth/',
  production: true
};
